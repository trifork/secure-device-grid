This is Trifork Device Grid Library
--------===========================--------

Copyright Trifork A/S, 2015.

Usage instructions:
===================

Unzip this zip-file, so that this README ends up in the root of the WICED-SDK.
This places thes tdblib in the ./libraries/trifork/tdglib directory.

Then build the demo app:

./make demo.tdg_chat-SN8000x download run

-replacing SN8000x with your platform name.

Then find the IP address of your wiced board, issue

telnet <IP> 123

The demo program runs a telnet listener on port 123, that responds to chat client commands.
The full source for this example program is in the ./apps/demo/tdg_chat/ directory.

Wifi config? in ./include/default_wifi_config_dct.h

Debug output? Modify ./apps/demo/tdg_chat/broadcom_main.c
finding assignment to "mdg_debug_log_target" and set it to:
// 0: for tty, USN or whereever printf goes.
// 1 for UDP-to-Trifork. This streams to UDP port 9999 on IP 77.66.11.94 at Trifork.


