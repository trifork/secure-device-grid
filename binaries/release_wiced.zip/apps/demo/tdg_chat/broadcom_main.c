
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdarg.h>
#include "wiced.h"

#include "mdg_peer_api.h"
#include "mdg_peer_storage.h"

char mdg_chat_platform[] = "Broadcom-WICED";

extern void hex_encode_bytes(const uint8_t *input, char *dst, int input_size);
extern int hex_decode_bytes(char *input, uint8_t *dst, int output_size);

// Creates our own pool for chat packets on Wiced.
// Wiced has very low a limit on buffers itself. Chat needs more...
#define MDG_CHAT_PACKET_MSG_SIZE 300
#define MDG_CHAT_PACKET_MSG_COUNT 30
#define MDG_CHAT_PACKET_POOL_SIZE (MDG_CHAT_PACKET_MSG_COUNT * MDG_CHAT_PACKET_MSG_SIZE)
#  define ___ULONGS ((MDG_CHAT_PACKET_POOL_SIZE + sizeof(ULONG) - 1) / sizeof(ULONG))
static ULONG mdg_chat_packet_pool_memory[___ULONGS];
NX_PACKET_POOL mdg_chat_packet_pool;


int io_socket_connected = 0;
wiced_tcp_socket_t io_socket;

#define MDG_PRIVATE_KEY_DATA_SIZE 32
uint8_t chatclient_private_key[MDG_PRIVATE_KEY_DATA_SIZE];
uint16_t listening_port = 123;

static wiced_semaphore_t pending_recv_packet;

extern void mdg_chat_client_input(char *in_buf, int len);

static void close_io_socket() {
  if (io_socket_connected) {
    nx_tcp_socket_disconnect(&io_socket.socket, NX_NO_WAIT);
    nx_tcp_client_socket_unbind(&io_socket.socket);
    io_socket_connected = 0;
  }
}

// Callback invoked by MDG lib.
int mdgstorage_load_random_base(uint8_t *random_base, uint32_t length)
{
  // TODO: In actual products, load random seed from flash here.
  // For demo purposes, this just hardwires the random seed to 0.
  // Length is probably 64. If you have a smaller seed, then just repeat it in the base.
  int i;
  uint8_t *p = random_base;
  for (i = 0; i < length; i++) {
    p[i] = 0;
  }
  return 0;
}

// Callback invoked by MDG lib.
int mdgstorage_load_private_key(void *private_key)
{
	memcpy(private_key, chatclient_private_key, MDG_PRIVATE_KEY_DATA_SIZE);
	return 0;
}

static char stdin_buf[1024], *rp = stdin_buf;

static char output_buffer[1000] = { 0 };
void mdg_chat_output_fprintf(const char *fmt, ...)
{
  if (io_socket_connected) {
    NX_PACKET *packet;
    va_list argp;
    va_start(argp, fmt);
    int output_count = vsprintf(output_buffer, fmt, argp);
    va_end(argp);

    int s = nx_packet_allocate(&mdg_chat_packet_pool,
                               &packet,
                               NX_TCP_PACKET,
                               NX_NO_WAIT);
    if (s != 0) {
      fprintf(stderr, "chat: nx_packet_allocate failed with %d.\n", s);
      return;
    }

    int i, j;
    unsigned char *d = packet->nx_packet_prepend_ptr;
    int buf_len = (packet->nx_packet_data_end - d);
    for (i = 0, j = 0; i < output_count && j < buf_len-2; i++, j++) {
      if (output_buffer[i] == '\n') {
        d[j++] = '\r';
      }
      d[j] = output_buffer[i];
    }
    packet->nx_packet_append_ptr = packet->nx_packet_prepend_ptr + j;
    packet->nx_packet_length = j;

    s = nx_tcp_socket_send(&io_socket.socket, packet, 200);
    if (s != NX_SUCCESS) {
      fprintf(stderr, "nx_tcp_socket_send failed in mdg_chat_output with %d.\n", s);
      nx_packet_release(packet);
    }
  }
}


// WICED_MINOR_VERSION is set in our tdg_chat.mk as we have yet to find one in the platform :(
#if WICED_MINOR_VERSION >= 3
wiced_result_t receive_cb(wiced_tcp_socket_t *socket, void *arg)
#else
wiced_result_t receive_cb(void *socket)
#endif
{
  if (wiced_rtos_set_semaphore(&pending_recv_packet)) {
    fprintf(stderr, "Failed to put pending_recv_packet sem\n");
  }
  return WICED_SUCCESS;
}

int wait_for_connection()
{
  int s;
  fprintf(stderr, "Okay, ready for chatclient-connection now\n");
  while ((s = wiced_tcp_accept(&io_socket)) != WICED_SUCCESS) {
    if (s != WICED_ERROR) {
      fprintf(stderr, "TCP socket accept operation failed with %d, retrying.\n", s);
    }
  }
  fprintf(stderr, "Chat client socket accept connected!\n");

#if WICED_MINOR_VERSION >= 3
  wiced_tcp_register_callbacks(&io_socket, NULL, &receive_cb, NULL, NULL);
#else
  wiced_tcp_register_callbacks(&io_socket, NULL, &receive_cb, NULL);
#endif
  io_socket_connected = 1;
  return WICED_SUCCESS;
}

void mdg_abort() {
  fprintf(stderr, "mdg_abort invoked!");
  while (1) {};
}

int wiced_chatclient_start()
{
  if (wiced_rtos_init_semaphore(&pending_recv_packet)) {
    fprintf(stderr, "Failed to init pending_recv_packet sem\n");
    return WICED_ERROR;
  }
  if (wiced_tcp_create_socket(&io_socket, WICED_STA_INTERFACE) != WICED_SUCCESS) {
    fprintf(stderr, "TCP socket creation failed\n");
    return WICED_ERROR;
  }
  if (wiced_tcp_listen(&io_socket, listening_port) != WICED_SUCCESS) {
    fprintf(stderr, "TCP socket listen operation failed\n");
    wiced_tcp_delete_socket((&io_socket));
    return WICED_ERROR;
  }
  return WICED_SUCCESS;
}

void handle_received_packages()
{
  wiced_packet_t* packet = 0;
  uint8_t *data, *dp;
  uint16_t data_length;
  uint16_t total_data_length;

  while (1) {
    UINT res = nx_tcp_socket_receive(&io_socket.socket, &packet, NX_NO_WAIT);

    if (res == NX_NO_PACKET) {
      return;
    } else if (res != NX_SUCCESS) {
      close_io_socket();
      return;
    }
    wiced_packet_get_data(packet, 0, &data, &data_length, &total_data_length);
    dp = data;
    while (rp < stdin_buf + sizeof(stdin_buf) && dp < data + data_length) {
      *rp = *dp++;
      int s = (int)*rp;
      if (s == 10) {
        mdg_chat_client_input(stdin_buf, rp - stdin_buf);
        rp = stdin_buf;
      }
      else if (s == 13) {
        //Ignore char, overwrite on next read.
      }
      else {
        ++rp;
      }
    }
    nx_packet_release(packet);
  }
}


extern void mdg_chat_init();
int mdg_demo_start()
{
	int s;
	if ((s = mdg_init(0)) != 0) {
		fprintf(stderr, "mdg_init failed with %d\n", s);
		return -1;
	}
        fprintf(stderr, "mdg_init completed.\n");

        if ((s = nx_packet_pool_create(&mdg_chat_packet_pool, "mdg_chat",
                                       MDG_CHAT_PACKET_MSG_SIZE,
                                       mdg_chat_packet_pool_memory,
                                       MDG_CHAT_PACKET_POOL_SIZE)) != NX_SUCCESS) {
          fprintf(stderr, "chat-client:nx_packet_pool_create failed %d\n", s);
          return 1;
        }

        mdg_chat_init();

        //mdg_set_mdns_service_type("wiced-chat-tgd");

        wiced_chatclient_start();
        fprintf(stderr, "wiced_chatclient_start completed.\n");

	// now wait for events to arrive
	while (1) {
          if (!io_socket_connected) {
            if (wait_for_connection() == WICED_SUCCESS) {
              char help[] = "/h ";
              mdg_chat_client_input(help, 3);
            }
          } else {
            wiced_rtos_get_semaphore(&pending_recv_packet, 1000);
            handle_received_packages();
            //wiced_rtos_delay_milliseconds(20);
          }
	}
	// break was called, so exit
	return 0;
}

void chatclient_parse_cmd_args()
{
	uint8_t *pk = chatclient_private_key;
	char hexed[128];
	for (int i = 0; i < MDG_PRIVATE_KEY_DATA_SIZE; i++) {
          pk[i] = 1;
	}
	hex_encode_bytes(pk, hexed, MDG_PRIVATE_KEY_DATA_SIZE);
	mdg_chat_output_fprintf("Chat-client, my private key %s\n", hexed);
}

void save_demo_email()
{
  //Ignored on this platform.
}

#ifdef DEBUG_TO_UDP
extern char mdg_debug_log_target_ip[];
extern int mdg_debug_log_target_port;
extern int mdg_debug_log_target;
#endif

void application_start() {
#ifdef DEBUG_TO_UDP
  fprintf(stderr, "application_start: Redirecting TDG debug output to UDP...\n");
  // Target: 0 for tty, 1 for UDP-to-Trifork.
  mdg_debug_log_target = 0;
  // Use thee lines to reconfigure the target ip+port of udp debug lines...
  strcpy(mdg_debug_log_target_ip, "77.66.11.94");
  mdg_debug_log_target_port = 9999;
#endif
  wiced_init();
  wiced_network_up(WICED_STA_INTERFACE, WICED_USE_EXTERNAL_DHCP_SERVER, NULL);
  chatclient_parse_cmd_args();
  mdg_demo_start();
}

void mdg_chat_client_exit() {
  close_io_socket();
}
