//
//  WelcomeViewController.swift
//  TDGChat
//
//  Created by Bjarke Hesthaven Søndergaard on 21/09/15.
//  Copyright © 2015 Trifork A/S. All rights reserved.
//

import UIKit
import TDG

public let UserEmailKey = "UserEmailKey"

class WelcomeViewController: UIViewController {
    @IBOutlet weak var emailTextField: UITextField!
    let core = TDGCore.sharedCore()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Welcome"
        
        self.emailTextField.text = NSUserDefaults.standardUserDefaults().stringForKey(UserEmailKey)
    }
    
    override func viewWillDisappear(animated: Bool) {
        NSUserDefaults.standardUserDefaults().setObject(self.emailTextField.text, forKey: UserEmailKey)
        NSUserDefaults.standardUserDefaults().synchronize()
        
        TDGClient.sharedClient.reconnect()
    }
}
