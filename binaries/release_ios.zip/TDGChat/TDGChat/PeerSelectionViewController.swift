//
//  PeerSelectionTableViewController.swift
//  TDGChat
//
//  Created by Bjarke Hesthaven Søndergaard on 21/09/15.
//  Copyright © 2015 Trifork A/S. All rights reserved.
//

import UIKit
import TDG

class PeerSelectionViewController: UIViewController {
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var outputLabel: UILabel! {
        didSet {
            outputLabel.text = " \n \n \n \n \n "
        }
    }
    
    let client = TDGClient.sharedClient
    
    var waitingConnection: TDGPeerConnection?

    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.title = "Select peer"
        self.tableView.dataSource = self
        self.tableView.delegate = self
        
        client.connectionDelegate = self
    }
    
    func appendOutputLog(log: String) {
        let current = outputLabel.text ?? ""
        let currentLines = current.characters.split("\n")
        var new = ""
        for (i, line) in currentLines.enumerate() {
            if currentLines.count >= 6 && i == 0 {
                continue
            }
            new += String(line) + "\n"
        }
        outputLabel.text = new + "\(log)"
    }
}

extension PeerSelectionViewController: UITableViewDataSource {
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }

    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return client.pairings.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("PeerCell", forIndexPath: indexPath)
        cell.textLabel?.text = client.peerName(client.pairings[indexPath.row])
        return cell
    }
}

extension PeerSelectionViewController: UITableViewDelegate {
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        self.waitingConnection = nil
        let peerId = client.pairings[indexPath.row]
        let peerName = client.peerName(peerId)
        appendOutputLog("Connecting to \(peerName)")
        client.connectToPeer(client.pairings[indexPath.row]) { connection, error in
            dispatch_async(dispatch_get_main_queue()) { [weak self] in
                if let error = error {
                    self?.appendOutputLog("Connect failed: \(error)")
                }
                else if let connection = connection {
                    if connection.connected {
                        self?.showConnection(connection)
                    }
                    else {
                        self?.waitingConnection = connection
                    }
                }
            }
        }
    }
}

extension PeerSelectionViewController {
    func showConnection(connection: TDGPeerConnection) {
        self.performSegueWithIdentifier("connection.start", sender: connection)
    }
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        if let chatVC = segue.destinationViewController as? ChatWithPeerViewController, connection = sender as? TDGPeerConnection {
            chatVC.connection = connection
            chatVC.messageStorage = self.client.messageStorage
        }
    }
}

extension PeerSelectionViewController: ConnectionDelegate {
    func routingStatusChanged(connection: TDGPeerConnection, status: TDGRoutingStatus) {
        let connId = connection.connectionId
        dispatch_async(dispatch_get_main_queue()) { [weak self, weak connection] in
            switch status {
            case .Connected:
                self?.appendOutputLog("Connected to peer on conn_id \(connId)")
                if let waitingConnection = self?.waitingConnection, connection = connection where waitingConnection.peerId == connection.peerId {
                    self?.showConnection(waitingConnection)
                }
            case .PeerNotAvailable:
                self?.appendOutputLog("Peer not available on conn_id \(connId)")
            case .Failed:
                self?.appendOutputLog("Connect failed on conn_id \(connId)")
            case .Disconnected:
                self?.appendOutputLog("Connect closed on conn_id \(connId)")
            case .Unknown:
                self?.appendOutputLog("Unknown error occurred on conn_id \(connId)")
            }
        }
    }
}
