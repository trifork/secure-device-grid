//
//  ConnectionsViewController.swift
//  TDG
//
//  Created by Bjarke Hesthaven Søndergaard on 03/09/15.
//  Copyright (c) 2015 Trifork A/S. All rights reserved.
//

import UIKit
import TDG

class ConnectionsViewController: UIViewController {
    @IBOutlet weak var receivedMessageLabel: UILabel!
    @IBOutlet weak var receivedHexMessageLabel: UILabel!
    @IBOutlet weak var sendMessageField: UITextField!
    @IBOutlet weak var connectionsTableView: UITableView!
    
    let core = TDGCore.sharedCore()

    override func viewDidLoad() {
        super.viewDidLoad()

        core.delegate = self
        
        connectionsTableView.dataSource = self
        
        self.receivedMessageLabel.text = ""
        self.receivedHexMessageLabel.text = ""
    }
}

extension ConnectionsViewController {
    @IBAction func connectToMdg(sender: AnyObject) {
        core.connect(["client_app_prop1": "mdg_chat_client", "client_app_prop2": ""]) { error in
            
        }
    }
    
    @IBAction func disconnectFromMdg(sender: AnyObject) {
        core.disconnect { error in
            
        }
    }
    
    @IBAction func retrieveStatus(sender: AnyObject) {
        core.status { status, error in
            if let status = status {
                print(status)
            }
        }
    }
    
    @IBAction func whoAmI(sender: AnyObject) {
        core.whoAmI { me, error in
            if let me = me {
                print(me)
            }
        }
    }
    
    @IBAction func sendMessage(sender: AnyObject) {
        if let row = self.connectionsTableView.indexPathForSelectedRow?.row where row < core.connections.count {
            let connection = core.connections[row] 
            connection.sendData(self.sendMessageField.text!.dataUsingEncoding(NSUTF8StringEncoding)!) { [weak self] error in
                if error == nil {
                    self?.sendMessageField.text = ""
                }
                else {
                    print(error)
                }
            }
        }
    }
    
    @IBAction func closeConnection(sender: AnyObject) {
        if let row = self.connectionsTableView.indexPathForSelectedRow?.row where row < core.connections.count {
            let connection = core.connections[row] 
            connection.closeConnection { error in
                
            }
        }
    }
    
    @IBAction func sendLaaa(sender: AnyObject) {
        if let row = self.connectionsTableView.indexPathForSelectedRow?.row where row < core.connections.count {
            let connection = core.connections[row] 
            let data = NSData(bytes: [0xC0, 0x00, 0x04, 0x00, 0x08, 0x0C, 0xC0] as [UInt8], length: 7)
            connection.sendData(data) { error in
                
            }
        }
    }
}

extension ConnectionsViewController: TDGCoreDelegate {
    func connection(connection: TDGPeerConnection, didReceiveData data: NSData) {
        dispatch_async(dispatch_get_main_queue()) {
            self.receivedHexMessageLabel.text = "\(connection.connectionId) - " + data.hexString
        }
        if let text = NSString(data: data, encoding: NSUTF8StringEncoding) as? String {
            dispatch_async(dispatch_get_main_queue()) {
                self.receivedMessageLabel.text = "\(connection.connectionId) - " + text
            }
        }
    }
}

extension ConnectionsViewController: UITableViewDataSource {
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return core.connections.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("ConnectionCell", forIndexPath: indexPath) 
        
        cell.textLabel?.text = "Connection \(indexPath.row)"
        
        return cell
    }
}