//
//  PairAsAppViewController.swift
//  TDGChat
//
//  Created by Bjarke Hesthaven Søndergaard on 21/09/15.
//  Copyright © 2015 Trifork A/S. All rights reserved.
//

import UIKit
import TDG

class PairAsAppViewController: UIViewController {
    @IBOutlet weak var otpTextField: UITextField!
    @IBOutlet weak var peerNameTextField: UITextField!
    @IBOutlet weak var statusLabel: UILabel! {
        didSet {
            statusLabel.text = "Not connected"
        }
    }
    
    let client = TDGClient.sharedClient

    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Pair as app"
        client.pairingDelegate = self
        // Do any additional setup after loading the view.
    }
}

// MARK: - Actions

extension PairAsAppViewController {
    @IBAction func pair(sender: AnyObject) {
        if let otp = self.otpTextField.text where otp.characters.count > 0 {
            self.statusLabel.text = "Not connected"
            self.otpTextField.text = ""
            client.pair(otp)
        }
    }
}

extension PairAsAppViewController: PairingDelegate {
    func pairingStateChanged(state: TDGPairingState) {
        print("Test \(state)")
        dispatch_async(dispatch_get_main_queue()) {
            self.statusLabel.text = state.status.stringValue
        }
        switch state.status {
        case .Completed:
            client.setPeerName(peerNameTextField.text, forPeerId: state.peerId)
        default:
            break
        }
    }
}