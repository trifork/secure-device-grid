//
//  PairAsDeviceViewController.swift
//  TDGChat
//
//  Created by Bjarke Hesthaven Søndergaard on 21/09/15.
//  Copyright © 2015 Trifork A/S. All rights reserved.
//

import UIKit
import TDG

class PairAsDeviceViewController: UIViewController {
    @IBOutlet weak var otpLabel: UILabel!
    @IBOutlet weak var peerNameTextField: UITextField!
    @IBOutlet weak var statusLabel: UILabel! {
        didSet {
            statusLabel.text = "Not connected"
        }
    }

    let client = TDGClient.sharedClient
    
    override func viewDidLoad() {
        super.viewDidLoad()

        self.title = "Pair as device"
        client.pairingDelegate = self
        // Do any additional setup after loading the view.
    }
    
    func formatOtp(otp: String) -> String {
        var formattedOtp = ""
        for (i, number) in otp.characters.enumerate() {
            formattedOtp.append(number)
            if (i % 3 == 2) && (i < otp.characters.count - 1) {
                formattedOtp += "-"
            }
        }
        return formattedOtp
    }
}

// MARK: - Actions

extension PairAsDeviceViewController {
    @IBAction func openForPairing(sender: AnyObject) {
        client.openForPairing()
    }
}

extension PairAsDeviceViewController: PairingDelegate {
    func pairingStateChanged(state: TDGPairingState) {
        if state.status == .Completed {
            client.setPeerName(peerNameTextField.text, forPeerId: state.peerId)
        }
        dispatch_async(dispatch_get_main_queue()) {
            self.statusLabel.text = state.status.stringValue
            if state.status == .OneTimePasscodeReady {
                self.otpLabel.text = self.formatOtp(state.oneTimePasscode)
            }
            else {
                self.otpLabel.text = ""
            }
        }
    }
}