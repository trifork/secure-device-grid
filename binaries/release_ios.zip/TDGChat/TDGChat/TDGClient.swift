//
//  TDGClient.swift
//  TDGChat
//
//  Created by Bjarke Hesthaven Søndergaard on 21/09/15.
//  Copyright © 2015 Trifork A/S. All rights reserved.
//

import UIKit
import TDG

let PeerNamesKey = "PeerNamesKey"

public protocol PairingDelegate: NSObjectProtocol {
    func pairingStateChanged(state: TDGPairingState)
}

public protocol ConnectionDelegate: NSObjectProtocol {
    func routingStatusChanged(connection: TDGPeerConnection, status: TDGRoutingStatus)
}

public class TDGClient: NSObject {
    public static let sharedClient = TDGClient()
    let messageStorage = MessageStorage()
    private let core = TDGCore.sharedCore()
    private var properties: [String: String] {
        var props = [String: String]()
        if let userEmail = NSUserDefaults.standardUserDefaults().stringForKey(UserEmailKey) {
            props["client_email"] = userEmail
        }
        return props
    }

    public var pairings: [String] {
        return core.pairings
    }
    
    private var peerNames: [String: String] = (NSUserDefaults.standardUserDefaults().objectForKey(PeerNamesKey) as? [String: String]) ?? [String: String]()
    
    public weak var pairingDelegate: PairingDelegate?
    public weak var connectionDelegate: ConnectionDelegate?
    
    private override init() {
        super.init()
        core.delegate = self
    }
    
    public func connect() {
        core.connect(self.properties) { error in
        }
    }
    
    public func disconnect() {
        core.disconnect { error in
        }
    }
    
    public func reconnect() {
        core.disconnect { [weak self] error in
            if error == nil {
                self?.connect()
            }
        }
    }
    
    public func pair(otp: String) {
        core.pairRemote(otp) { error in
        }
    }
    
    public func openForPairing() {
        core.enablePairingMode(120) { error in
        }
    }
    
    public func connectToPeer(peerId: String, completion: (TDGPeerConnection?, NSError?) -> Void) {
        if let connectionIndex = self.core.connections.indexOf({ $0.peerId == peerId }) {
            completion(self.core.connections[connectionIndex], nil)
        }
        else {
            core.placeCallRemote(peerId, protocolName: "chat-client", timeout: 10) { connection, error in
                completion(connection, error)
            }
        }
    }
    
    public func setPeerName(name: String?, forPeerId peerId: String) {
        guard let name = name where name != "" else {
            return
        }
        peerNames[peerId] = name
        NSUserDefaults.standardUserDefaults().setObject(peerNames, forKey: PeerNamesKey)
        NSUserDefaults.standardUserDefaults().synchronize()
    }
    
    public func peerName(peerId: String) -> String {
        if let peerName = peerNames[peerId] where peerName != "" {
            return peerName
        }
        return peerId.substringToIndex(peerId.startIndex.advancedBy(12)) + "..."
    }
}

extension TDGClient: TDGCoreDelegate {
    public func pairingStateChanged(state: TDGPairingState) {
        if let delegate = pairingDelegate {
            delegate.pairingStateChanged(state)
        }
    }
    
    public func routingStatusChanged(connection: TDGPeerConnection, toStatus status: TDGRoutingStatus) {
        connection.delegate = self
        if let delegate = connectionDelegate {
            delegate.routingStatusChanged(connection, status: status)
        }
    }
}

extension TDGClient: TDGPeerConnectionDelegate {
    public func connection(connection: TDGPeerConnection, didReceiveData data: NSData) {
        self.messageStorage.addData(data, forConnection: connection, sender: .Them)
    }
}