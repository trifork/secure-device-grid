//
//  PairingsViewController.swift
//  TDG
//
//  Created by Bjarke Hesthaven Søndergaard on 03/09/15.
//  Copyright (c) 2015 Trifork A/S. All rights reserved.
//

import UIKit
import TDG

class PairingsViewController: UIViewController {
    @IBOutlet weak var myOTPLabel: UILabel!
    @IBOutlet weak var otpField: UITextField!
    @IBOutlet weak var ipField: UITextField!
    @IBOutlet weak var portField: UITextField!
    @IBOutlet weak var pairingsTableView: UITableView!
    
    let core = TDGCore.sharedCore()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        core.delegate = self
        myOTPLabel.text = ""
        
        pairingsTableView.dataSource = self
        pairingsTableView.layoutMargins = UIEdgeInsetsZero
    }
}

extension PairingsViewController {
    @IBAction func connectToMdg(sender: AnyObject) {
        core.connect(["client_app_prop1": "mdg_chat_client", "client_app_prop2": ""]) { error in
        
        }
    }
    
    @IBAction func disconnectFromMdg(sender: AnyObject) {
        core.disconnect() { error in
            
        }
    }
    
    @IBAction func retrieveStatus(sender: AnyObject) {
        core.status { status, error in
            if let status = status {
                print(status)
            }
        }
    }
    
    @IBAction func whoAmI(sender: AnyObject) {
        core.whoAmI { me, error in
            if let me = me {
                print(me)
            }
        }
    }
    
    @IBAction func enablePairingMode(sender: AnyObject) {
        core.enablePairingMode(120) { error in
            if let error = error {
                print(error)
            }
        }
    }
    
    @IBAction func disablePairingMode(sender: AnyObject) {
        core.disablePairingMode {
            
        }
    }
    
    @IBAction func pairRemote(sender: AnyObject) {
        core.pairRemote(self.otpField.text!) { [weak self] error in
            if error == nil {
                self?.otpField.text = ""
                self?.ipField.text = ""
                self?.portField.text = ""
            }
        }
    }
    
    @IBAction func pairLocal(sender: AnyObject) {
        if let row = self.pairingsTableView.indexPathForSelectedRow?.row where row < core.pairings.count {
            core.placeCallLocal("la", protocolName: "la", peerIp: "la", port: 10) { connection, error in
            
            }
        }
    }
    
    @IBAction func placeCallRemote(sender: AnyObject) {
        if let row = self.pairingsTableView.indexPathForSelectedRow?.row where row < core.pairings.count {
            core.placeCallRemote(core.pairings[row], protocolName: "chat-client", timeout: 5) { connection, error in
                //                println(error)
            }
        }
    }
}

extension PairingsViewController: TDGCoreDelegate {
    func pairingStateChanged(state: TDGPairingState) {
        dispatch_async(dispatch_get_main_queue()) { [weak self] in
            self?.myOTPLabel.text = state.oneTimePasscode
        }
    }
    
    func coreDidUpdatePairings(pairings: [String]) {
        dispatch_async(dispatch_get_main_queue(), { () -> Void in
            self.pairingsTableView.reloadData()
        })
    }
}

extension PairingsViewController: UITableViewDataSource {
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return core.pairings.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("PairingCell", forIndexPath: indexPath) 
        
        let peerId = core.pairings[indexPath.row]
        cell.textLabel?.text = peerId
        
        return cell
    }
}
