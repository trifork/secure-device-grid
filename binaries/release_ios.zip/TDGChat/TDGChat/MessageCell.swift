//
//  MessageCell.swift
//  TDGChat
//
//  Created by Bjarke Hesthaven Søndergaard on 21/09/15.
//  Copyright © 2015 Trifork A/S. All rights reserved.
//

import UIKit

let triforkOrange = UIColor(red: 253/255, green: 120/255, blue: 36/250, alpha: 1)

class MessageCell: UITableViewCell {
    @IBOutlet weak var messageLabel: UILabel!
    var leadingMessageLabelConstraintThem: NSLayoutConstraint!
    var leadingMessageLabelConstraintMe: NSLayoutConstraint!
    var trailingMessageLabelConstraintThem: NSLayoutConstraint!
    var trailingMessageLabelConstraintMe: NSLayoutConstraint!
    let textColorThem = UIColor.darkTextColor()
    let textColorMe = triforkOrange
    let backgroundColorThem = UIColor(red: 1.0, green: 132/255, blue: 0/250, alpha: 0.5)
    let backgroundColorMe = UIColor(red: 204/255, green: 204/255, blue: 204/255, alpha: 1)
    let closestEdge: CGFloat = 5
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        leadingMessageLabelConstraintThem = NSLayoutConstraint(item: messageLabel, attribute: .Leading, relatedBy: .Equal, toItem: contentView, attribute: .LeadingMargin, multiplier: 1, constant: closestEdge)
        leadingMessageLabelConstraintMe = NSLayoutConstraint(item: messageLabel, attribute: .Leading, relatedBy: .GreaterThanOrEqual, toItem: contentView, attribute: .LeadingMargin, multiplier: 1, constant: 0)
        trailingMessageLabelConstraintThem = NSLayoutConstraint(item: contentView, attribute: .TrailingMargin, relatedBy: .GreaterThanOrEqual, toItem: messageLabel, attribute: .Trailing, multiplier: 1, constant: 0)
        trailingMessageLabelConstraintMe = NSLayoutConstraint(item: contentView, attribute: .TrailingMargin, relatedBy: .Equal, toItem: messageLabel, attribute: .Trailing, multiplier: 1, constant: closestEdge)
    }
    
    var message: Message? {
        didSet {
            messageLabel.text = message?.text
            setSender(message?.sender)
        }
    }
    
    override func prepareForReuse() {
        super.prepareForReuse()
        
        messageLabel.text = ""
        message = nil
    }
    
    func setSender(sender: MessageSender?) {
        let isMe = sender == .Me
        leadingMessageLabelConstraintMe.active = isMe
        trailingMessageLabelConstraintMe.active = isMe
        leadingMessageLabelConstraintThem.active = !isMe
        trailingMessageLabelConstraintThem.active = !isMe
        messageLabel.textColor = isMe ? textColorMe : textColorThem
//        contentView.backgroundColor = isMe ? backgroundColorMe : backgroundColorThem
    }
}
