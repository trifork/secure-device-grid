//
//  TDGError.h
//  TDG
//
//  Created by Bjarke Hesthaven Søndergaard on 02/09/15.
//  Copyright (c) 2015 Trifork A/S. All rights reserved.
//

@import Foundation;

typedef NS_ENUM(NSUInteger, TDGErrorType) {
    TDGErrorTypeUnknown                 = 0,
    TDGErrorTypeGeneric                 = 1,
    TDGErrorTypeIncorrectMethodInput    = 2,
    TDGErrorTypeCommandFailed           = 3,
    TDGErrorTypeConnectionDisconnected  = 4
};

NS_ASSUME_NONNULL_BEGIN
@interface TDGError : NSError

- (instancetype)initWithTDGErrorType:(TDGErrorType)errorType reason:(NSString * __nullable)reason;
+ (instancetype)errorWithTDGErrorType:(TDGErrorType)errorType;
+ (instancetype)errorWithTDGErrorType:(TDGErrorType)errorType reason:(NSString * __nullable)reason;

- (instancetype)initWithCommandFailedWithResult:(NSInteger)result;
+ (instancetype)errorWithCommandFailedWithResult:(NSInteger)result;

@end
NS_ASSUME_NONNULL_END