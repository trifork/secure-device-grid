//
//  TDG.h
//  TDG
//
//  Created by Bjarke Hesthaven Søndergaard on 28/08/15.
//  Copyright (c) 2015 Trifork A/S. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for TDG.
FOUNDATION_EXPORT double TDGVersionNumber;

//! Project version string for TDG.
FOUNDATION_EXPORT const unsigned char TDGVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <TDG/PublicHeader.h>

#import <TDG/TDGCore.h>
#import <TDG/TDGError.h>
#import <TDG/TDGPairingState.h>
#import <TDG/TDGPeerConnection.h>
#import <TDG/TDGStatus.h>
