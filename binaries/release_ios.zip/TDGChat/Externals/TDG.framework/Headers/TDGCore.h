//
//  TDGCore.h
//  TDG-iOS
//
//  Created by Bjarke Hesthaven Søndergaard on 17/08/15.
//  Copyright (c) 2015 Trifork A/S. All rights reserved.
//

@import Foundation;

@class TDGStatus;
@class TDGPairingState;
@class TDGPeerConnection;
@class TDGError;

typedef NS_ENUM(NSInteger, TDGRoutingStatus) {
    TDGRoutingStatusPeerNotAvailable        = -2,
    TDGRoutingStatusFailed                  = -1,
    TDGRoutingStatusDisconnected            = 0,
    TDGRoutingStatusConnected               = 1,
    TDGRoutingStatusUnknown                 = -9999
};

typedef NS_ENUM(NSInteger, TDGPairingStatus) {
    TDGPairingStatusStarting                = 0,
    TDGPairingStatusOneTimePasscodeReady    = 1,
    TDGPairingStatusCompleted               = 2,
    TDGPairingStatusFailedGeneric           = 3,
    TDGPairingStatusFailedOneTimePasscode   = 4,
    TDGPairingStatusUnknown                 = -9999
};

@protocol TDGCoreDelegate;

NS_ASSUME_NONNULL_BEGIN
@interface TDGCore : NSObject

@property (weak, nonatomic, nullable) id<TDGCoreDelegate> delegate;
@property (copy, nonatomic, readonly) NSArray<TDGPeerConnection *> *connections;
@property (copy, nonatomic, readonly) NSArray<NSString *> *pairings;
@property (nonatomic) BOOL persistence;

- (instancetype)init NS_UNAVAILABLE;

+ (instancetype)sharedCore;

#pragma mark - General
- (void)status:(void (^)(TDGStatus * __nullable status, TDGError * __nullable error))completionBlock;
- (void)aggressivePing:(NSUInteger)durationInSeconds completionBlock:(void (^ __nullable)(TDGError * __nullable error))completionBlock;
- (void)whoAmI:(void (^)(NSString * __nullable whoAmI, TDGError * __nullable error))completionBlock;

#pragma mark - Connection to MDG
- (void)connect:(NSDictionary *)properties completionBlock:(void (^ __nullable)(TDGError * __nullable error))completionBlock;
- (void)disconnect:(void (^ __nullable)(TDGError * __nullable error))completionBlock;

#pragma mark - Pairings
- (void)enablePairingMode:(NSUInteger)durationInSeconds completionBlock:(void (^ __nullable)(TDGError * __nullable error))completionBlock;
- (void)disablePairingMode:(void (^ __nullable)())completionBlock;
- (void)addPairing:(NSString *)peerId completionBlock:(void (^ __nullable)(TDGError * __nullable error))completionBlock;
- (void)revokePairing:(NSString *)peerId completionBlock:(void (^ __nullable)(TDGError * __nullable error))completionBlock;
- (void)revokeAllPairings:(void (^ __nullable)(TDGError * __nullable error))completionBlock;

- (void)pairRemote:(NSString *)oneTimePasscode completionBlock:(void (^ __nullable)(TDGError * __nullable error))completionBlock;
- (void)pairLocal:(NSString *)oneTimePasscode peerIp:(NSString *)ip port:(NSUInteger)port completionBlock:(void (^ __nullable)(TDGError * __nullable error))completionBlock;

#pragma mark - Connection to peer
- (void)placeCallRemote:(NSString *)peerId protocolName:(NSString *)protocolName timeout:(NSUInteger)timeoutInSeconds completionBlock:(void (^)(TDGPeerConnection * __nullable connection, TDGError * __nullable error))completionBlock;
- (void)placeCallLocal:(NSString *)peerId protocolName:(NSString *)protocolName peerIp:(NSString *)peerIp port:(NSUInteger)port completionBlock:(void (^)(TDGPeerConnection * __nullable connection, TDGError * __nullable error))completionBlock;

#pragma mark - Debugging
- (void)enableRemoteLogging:(NSUInteger)durationInSeconds completionBlock:(void (^)(TDGError *error))completionBlock;
- (void)setDebugLogTarget:(NSInteger)target completionBlock:(void (^)(TDGError *error))completionBlock;

@end

@protocol TDGCoreDelegate <NSObject>

@optional
- (void)pairingStateChanged:(TDGPairingState *)state;
- (void)routingStatusChanged:(TDGPeerConnection *)connection toStatus:(TDGRoutingStatus)status;
- (BOOL)acceptIncomingCallFromPeerWithProtocolName:(NSString *)protocolName; // Default behavior is true
- (void)coreDidUpdatePairings:(NSArray<NSString *> *)pairings;
- (void)coreDidUpdateConnections:(NSArray<TDGPeerConnection *> *)connections;

@end
NS_ASSUME_NONNULL_END
