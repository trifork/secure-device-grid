//
//  TDGPeerConnection.h
//  TDG-iOS
//
//  Created by Bjarke Hesthaven Søndergaard on 27/08/15.
//  Copyright (c) 2015 Trifork A/S. All rights reserved.
//

@import Foundation;

@class TDGError;

@protocol TDGPeerConnectionDelegate;

NS_ASSUME_NONNULL_BEGIN
@interface TDGPeerConnection : NSObject

@property (weak, nonatomic) id<TDGPeerConnectionDelegate> delegate;
@property (nonatomic, readonly) NSUInteger connectionId;
@property (nonatomic, readonly, nullable) NSString *peerId;
@property (nonatomic, readonly) BOOL connected;

- (instancetype)init NS_UNAVAILABLE;

#pragma mark - Send/Receive
- (void)sendData:(NSData *)data completionBlock:(nullable void (^)(TDGError * _Nullable error))completionBlock;
- (void)closeConnection:(nullable void (^)(TDGError * _Nullable error))completionBlock;

@end

@protocol TDGPeerConnectionDelegate <NSObject>

@optional
- (void)connection:(TDGPeerConnection *)connection didReceiveData:(NSData *)data;

@end
NS_ASSUME_NONNULL_END
