#ifdef MDG_CC3200

#include "defines_cc3200.h"
#include "simplelink.h"
#include "mode_cc3200.h"

extern volatile bool is_connected;
extern volatile bool has_ip_address;
extern void UART_PRINT(const char *format, ...);

bool goto_station_mode()
{
	_i16 ret_val;

	ret_val = sl_WlanSetMode(ROLE_STA);
	if (ret_val != 0) {
		UART_PRINT("sl_WlanSetMode error\n");
		return false;
	}

	while (sl_Stop(0) != 0) {
		UART_PRINT("sl_Stop error loop\n");
		_SlNonOsMainLoopTask();
	}

	//clear status
	is_connected = false;
	has_ip_address = false;

	ret_val = sl_Start(0, 0, 0);
	if (ret_val != ROLE_STA) {
		UART_PRINT("sl_Start error %i\n", ret_val);
		return false;
	}

	UART_PRINT("Device is now in station mode\n");
	return true;
}

bool goto_ap_mode()
{
	_i16 ret_val;
	_u8 ssid[] = "CC3200";

	ret_val = sl_WlanSetMode(ROLE_AP);
	if (ret_val != 0) {
		UART_PRINT("sl_WlanSetMode error\n");
		return false;
	}

	ret_val = sl_WlanSet(SL_WLAN_CFG_AP_ID, WLAN_AP_OPT_SSID, strlen(ssid), ssid);
	if (ret_val != 0) {
		UART_PRINT("sl_WlanSet error %i\n", ret_val);
		return false;
	}

	while (sl_Stop(0) != 0) {
		UART_PRINT("sl_Stop error loop\n");
		_SlNonOsMainLoopTask();
	}

	//clear status
	is_connected = false;
	has_ip_address = false;

	ret_val = sl_Start(0, 0, 0);
	if (ret_val != ROLE_AP) {
		UART_PRINT("sl_Start error %i\n", ret_val);
		return false;
	}

	UART_PRINT("Device is now in AP mode\n");
	return true;
}

#endif //MDG_CC3200
