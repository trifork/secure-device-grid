#ifdef MDG_CC3200
#pragma once

#ifdef NOTERM
#define UART_PRINT(x,...)
#define DBG_PRINT(x,...)
#define ERR_PRINT(x)
#else
#define UART_PRINT Report
#define DBG_PRINT  Report
#define ERR_PRINT(x) Report("Error [%d] at line [%d] in function [%s]  \n\r",x,__LINE__,__FUNCTION__)
#endif

#define SL_STOP_TIMEOUT         200
#define WIFI_SSID				"trifork-guest"
#define WIFI_PASSWORD			"trifork2048"

#endif //MDG_CC3200
