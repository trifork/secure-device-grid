#ifdef MDG_CC3200

#include <stdio.h> //vsprintf

#include "mdg_peer_api.h"
#include "mdg_peer_storage.h"
#include "simplelink.h"
#include "defines_cc3200.h"
#include "uart_if.h"

char mdg_chat_platform[] = "TI-CC3200";

#define BUFFER_LENGTH 1024
#define IO_PORT 123

extern void mdg_chat_client_input(char *stdin_buf, int len);
extern void cc3200_init();
extern void cc3200_shutdown();
extern void mdg_step();

void mdg_chat_client_exit();
void mdg_chat_output_fprintf(const char *fmt, ...);

static int mdg_ev_main();
static int listen_on_socket(_i16 socketId, _u16 port);
static int wait_for_connection(int port);
static int cc3200_chatclient_start();
static void do_select();
static void handle_input(_u8 *data, _i16 data_length);

_i16 io_socket;
uint8_t chatclient_private_key[MDG_PRIVATE_KEY_DATA_SIZE];
static char stdin_buf[BUFFER_LENGTH], *rp = stdin_buf;

void main()
{
	cc3200_init();
	mdg_ev_main();
	cc3200_shutdown();
}

void save_demo_email()
{}

void mdg_chat_client_exit()
{
	UART_PRINT("mdg_chat_client_exit\r\n");
	cc3200_shutdown();
}

void mdg_abort()
{
	UART_PRINT("mdg_abort\r\n");
	cc3200_shutdown();
}

void mdg_chat_output_fprintf(const char *fmt, ...)
{
	char buffer[BUFFER_LENGTH] = { 0 };
	char fixedBuffer[BUFFER_LENGTH * 2] = { 0 };
	va_list argp;
	va_start(argp, fmt);
	int output_count = vsprintf(buffer, fmt, argp);
	va_end(argp);
	int i;
	for (i = 0; i < output_count; ++i) {
		if (buffer[i] == '\n') {
			fixedBuffer[i] = '\r';
			fixedBuffer[i + 1] = '\n';
			++i;
		} else {
			fixedBuffer[i] = buffer[i];
		}
	}
	output_count = i;

	int send_count_total = 0;
	int send_count = 0;
	while (send_count_total < output_count) {
		send_count = sl_Send(io_socket, fixedBuffer, output_count - send_count, 0);
		if (send_count > 0) {
			send_count_total += send_count;
		} else {
			return;
		}
	}
}

int mdgstorage_load_private_key(void *private_key)
{
	memcpy(private_key, chatclient_private_key, MDG_PRIVATE_KEY_DATA_SIZE);
	return 0;
}

// Callback invoked by MDG lib.
int mdgstorage_load_random_base(uint8_t *random_base, uint32_t length)
{
  // TODO: In actual products, load random seed from flash here.
  // For demo purposes, this just hardwires the random seed to 0.
  // Length is probably 64. If you have a smaller seed, then just repeat it in the base.
  int i;
  uint8_t *p = random_base;
  for (i = 0; i < length; i++) {
    p[i] = 0;
  }
  return 0;
}
static int mdg_ev_main()
{
	int s;
	if ((s = mdg_init(0)) != 0) {
		UART_PRINT("mdg_init failed with %d\n", s);
		return -1;
	}
        mdg_set_mdns_service_type("cc3200-chat-tdg");

	if (cc3200_chatclient_start() != 0) {
		return -1;
	}

	while (1) {
#ifndef SL_PLATFORM_MULTI_THREADED
		_SlNonOsMainLoopTask();
#endif
		mdg_step();
		do_select();
	}
}

static int listen_on_socket(_i16 socketId, _u16 port)
{
	SlSockAddrIn_t address;
	_i16 ret_val;

	address.sin_family = SL_AF_INET;
	address.sin_port = sl_Htons(port);
	address.sin_addr.s_addr = sl_Htonl(SL_INADDR_ANY);

	ret_val = sl_Bind(socketId, (SlSockAddr_t*) &address, sizeof(address));
	if (ret_val < 0) {
		UART_PRINT("sl_Bind error (%d)\n", ret_val);
		return -1;
	}

	ret_val = sl_Listen(socketId, 5);
	if (ret_val < 0) {
		UART_PRINT("sl_Listen error (%d)\n", ret_val);
		return -1;
	}

	return 0;
}


static int wait_for_connection(int port)
{
	_i16 listening_socket;
	SlSockAddrIn_t remote_addr;
	SlSocklen_t remote_size = sizeof(remote_addr);

	listening_socket = sl_Socket(SL_AF_INET, SL_SOCK_STREAM, IPPROTO_TCP);
	if (listening_socket < 0) {
		UART_PRINT("sl_Socket error (%d)\n", listening_socket);
		return -1;
	}

	if (listen_on_socket(listening_socket, port) != 0) {
		return -1;
	}

	io_socket = sl_Accept(listening_socket, (SlSockAddr_t*) &remote_addr, &remote_size);
	if (io_socket < 0) {
		UART_PRINT("sl_Accept error (%d)\n", io_socket);
		return -1;
	}

	sl_Close(listening_socket);
	UART_PRINT("Connected to i/o socket\n");
	mdg_chat_output_fprintf("Connected!\n");

	return 0;
}

static int cc3200_chatclient_start()
{
	if (wait_for_connection(IO_PORT) != 0) {
		return -1;
	}
	char help[] = "/h ";
	mdg_chat_client_input(help, 3);
	return 0;
}

static void do_select()
{
	_i16 ret_val;
	SlFdSet_t read_fds;
	SlTimeval_t tv;
	tv.tv_sec = 0;
	tv.tv_usec = 0; //The minimum timeout is 10 milliseconds
	_u8 buffer[BUFFER_LENGTH];

	SL_FD_ZERO(&read_fds);
	SL_FD_SET(io_socket, &read_fds);
	ret_val = sl_Select(io_socket + 1, &read_fds, 0, 0, &tv);
	if (ret_val <= 0 || !SL_FD_ISSET(io_socket, &read_fds)) {
		return;
	}

	ret_val = sl_Recv(io_socket, buffer, BUFFER_LENGTH, 0);
	if (ret_val <= 0) {
		return;
	}

	handle_input(buffer, ret_val);
}

static void handle_input(_u8 *data, _i16 data_length)
{
	int i;
	for (i = 0; i < data_length; ++i) {
		*rp = data[i];
		if (*rp == 10) {
			mdg_chat_client_input(stdin_buf, rp - stdin_buf);
			rp = stdin_buf;
		} else if (*rp == 13) {
			//Ignore char, overwrite on next read.
		} else {
			++rp;
		}
	}
}

#endif //MDG_CC3200
