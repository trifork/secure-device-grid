#ifdef MDG_CC3200

#pragma once

#include "stdbool.h"

bool goto_station_mode();
bool goto_ap_mode();

#endif //MDG_CC3200
