#ifdef MDG_CC3200

#include "defines_cc3200.h"
#include "simplelink.h"
#include "hw_ints.h"
#include "gpio_if.h"
#include "common.h"
#include "hw_types.h"
#include "uart_if.h"
#include "interrupt.h"
#include "prcm.h"
#include "pin.h"
#include "hw_memmap.h"
#include "gpio.h"
#include "rom_map.h"
#include "mode_cc3200.h"

volatile int is_connected;
volatile int has_ip_address;

extern void (* const g_pfnVectors[])(void);

void cc3200_init();
void cc3200_shutdown();
void setup_pin_mux();
void board_init();
int configure_simplelink_to_default_state();

void SimpleLinkWlanEventHandler(SlWlanEvent_t *pWlanEvent) {
	if (!pWlanEvent) {
		return;
	}

	switch (pWlanEvent->Event) {
	case SL_WLAN_CONNECT_EVENT: {
		slWlanConnectAsyncResponse_t *event_data =
				&pWlanEvent->EventData.STAandP2PModeWlanConnected;
		is_connected = 1;
		UART_PRINT("[WLAN EVENT] connected to ssid: %.*s\n",
				event_data->ssid_len, event_data->ssid_name);
		UART_PRINT("bssid: %x:%x:%x:%x:%x:%x\n", event_data->bssid[0],
				event_data->bssid[1], event_data->bssid[2],
				event_data->bssid[3], event_data->bssid[4],
				event_data->bssid[5]);
	}
		break;

	case SL_WLAN_DISCONNECT_EVENT: {
		slWlanConnectAsyncResponse_t *event_data =
				&pWlanEvent->EventData.STAandP2PModeDisconnected;
		is_connected = 0;
		has_ip_address = 0;
		if (event_data->reason_code == SL_USER_INITIATED_DISCONNECTION) {
			UART_PRINT(
					"[WLAN EVENT] disconnected on application's request\n");
		} else {
			UART_PRINT("[WLAN EVENT] disconnected due to error\n");
		}
	}
		break;

	case SL_WLAN_STA_CONNECTED_EVENT:
		UART_PRINT("[WLAN EVENT] SL_WLAN_STA_CONNECTED_EVENT\n");
		break;

	case SL_WLAN_STA_DISCONNECTED_EVENT:
		UART_PRINT("[WLAN EVENT] SL_WLAN_STA_DISCONNECTED_EVENT\n");
		break;

	default:
		UART_PRINT("[WLAN EVENT] Unexpected event [0x%x]\n",
				pWlanEvent->Event);
	}
}

void SimpleLinkNetAppEventHandler(SlNetAppEvent_t *pNetAppEvent) {
	if (!pNetAppEvent) {
		return;
	}

	switch (pNetAppEvent->Event) {
	case SL_NETAPP_IPV4_IPACQUIRED_EVENT: {
		SlIpV4AcquiredAsync_t *event_data =
				&pNetAppEvent->EventData.ipAcquiredV4;
		UART_PRINT("[NETAPP EVENT] ip acquired: %u.%u.%u.%u\n",
				SL_IPV4_BYTE(event_data->ip, 3),
				SL_IPV4_BYTE(event_data->ip, 2),
				SL_IPV4_BYTE(event_data->ip, 1),
				SL_IPV4_BYTE(event_data->ip, 0));
		UART_PRINT("gateway: %u.%u.%u.%u\n",
				SL_IPV4_BYTE(event_data->gateway, 3),
				SL_IPV4_BYTE(event_data->gateway, 2),
				SL_IPV4_BYTE(event_data->gateway, 1),
				SL_IPV4_BYTE(event_data->gateway, 0));
		has_ip_address = 1;
	}
		break;

	case SL_NETAPP_IP_LEASED_EVENT: {
		SlIpLeasedAsync_t *event_data = &pNetAppEvent->EventData.ipLeased;
		UART_PRINT("[NETAPP EVENT] ip leased: %u.%u.%u.%u\n",
				SL_IPV4_BYTE(event_data->ip_address, 3),
				SL_IPV4_BYTE(event_data->ip_address, 2),
				SL_IPV4_BYTE(event_data->ip_address, 1),
				SL_IPV4_BYTE(event_data->ip_address, 0));
	}
		break;

	default:
		UART_PRINT("[NETAPP EVENT] Unexpected event [0x%x]\n",
				pNetAppEvent->Event);
	}
}

void SimpleLinkHttpServerCallback(SlHttpServerEvent_t *pHttpEvent,
		SlHttpServerResponse_t *pHttpResponse) {
}

void SimpleLinkGeneralEventHandler(SlDeviceEvent_t *pDevEvent) {
	if (!pDevEvent) {
		return;
	}

	UART_PRINT("[GENERAL EVENT] - ID=[%d] Sender=[%d]\n\n",
			pDevEvent->EventData.deviceEvent.status,
			pDevEvent->EventData.deviceEvent.sender);
}

void SimpleLinkSockEventHandler(SlSockEvent_t *pSock) {
	if (!pSock) {
		return;
	}

	switch (pSock->Event) {
	case SL_SOCKET_TX_FAILED_EVENT:
		switch (pSock->socketAsyncEvent.SockTxFailData.status) {
		case SL_ECLOSE:
            UART_PRINT("[SOCK ERROR] - close socket (%d) operation "
                        "failed to transmit all queued packets\n\n",
                            pSock->socketAsyncEvent.SockTxFailData.sd);
			break;
		default:
            UART_PRINT("[SOCK ERROR] - TX FAILED  :  socket %d , reason "
                        "(%d) \n\n",
                        pSock->socketAsyncEvent.SockTxFailData.sd, pSock->socketAsyncEvent.SockTxFailData.status);
		}
		break;
	}
}

int configure_simplelink_to_default_state() {
	_i16 ret_val;
	_WlanRxFilterOperationCommandBuff_t RxFilterIdMask = { 0 };

	unsigned char value = 1;
	unsigned char config_option = 0;
	unsigned char power = 0;

	ret_val = sl_Start(0, 0, 0);
	if (ret_val < 0) {
		UART_PRINT("sl_Start error %i\n", ret_val);
		return 0;
	}

	if (ret_val != ROLE_STA) {
		if (!goto_station_mode()) {
			return 0;
		}
	}

	// Set connection policy to Auto + SmartConfig
	//      (Device's default connection policy)
	ret_val = sl_WlanPolicySet(SL_POLICY_CONNECTION,
			SL_CONNECTION_POLICY(1, 0, 0, 0, 1), NULL, 0);
	if (ret_val < 0) {
		UART_PRINT("sl_WlanPolicySet error\n");
		return 0;
	}

	// Remove all profiles
	ret_val = sl_WlanProfileDel(0xFF);
	if (ret_val < 0) {
		UART_PRINT("sl_WlanProfileDel error\n");
		return 0;
	}

	//
	// Device in station-mode. Disconnect previous connection if any
	// The function returns 0 if 'Disconnected done', negative number if already
	// disconnected Wait for 'disconnection' event if 0 is returned, Ignore
	// other return-codes
	//
	ret_val = sl_WlanDisconnect();
	if (ret_val == 0) {
		while (!is_connected) {
#ifndef SL_PLATFORM_MULTI_THREADED
			_SlNonOsMainLoopTask();
#endif
		}
	}

	// Enable DHCP client
	ret_val = sl_NetCfgSet(SL_IPV4_STA_P2P_CL_DHCP_ENABLE, 1, 1, &value);
	if (ret_val < 0) {
		UART_PRINT("sl_NetCfgSet error\n");
		return 0;
	}

	// Disable scan
	config_option = SL_SCAN_POLICY(0);
	ret_val = sl_WlanPolicySet(SL_POLICY_SCAN, config_option, NULL, 0);
	if (ret_val < 0) {
		UART_PRINT("sl_WlanPolicySet error\n");
		return 0;
	}

	// Set Tx power level for station mode
	// Number between 0-15, as dB offset from max power - 0 will set max power
	power = 0;
	ret_val = sl_WlanSet(SL_WLAN_CFG_GENERAL_PARAM_ID,
			WLAN_GENERAL_PARAM_OPT_STA_TX_POWER, 1, (unsigned char *) &power);
	if (ret_val < 0) {
		UART_PRINT("sl_WlanSet error\n");
		return 0;
	}

	// Set PM policy to normal
	ret_val = sl_WlanPolicySet(SL_POLICY_PM, SL_NORMAL_POLICY, NULL, 0);
	if (ret_val < 0) {
		UART_PRINT("sl_WlanPolicySet error\n");
		return 0;
	}

	// Unregister mDNS services
	ret_val = sl_NetAppMDNSUnRegisterService(0, 0);
	if (ret_val < 0) {
		UART_PRINT("sl_NetAppMDNSUnRegisterService error\n");
		return 0;
	}

	// Remove  all 64 filters (8*8)
	memset(RxFilterIdMask.FilterIdMask, 0xFF, 8);
	ret_val = sl_WlanRxFilterSet(SL_REMOVE_RX_FILTER, (_u8 *) &RxFilterIdMask,
			sizeof(_WlanRxFilterOperationCommandBuff_t));
	if (ret_val < 0) {
		UART_PRINT("sl_WlanRxFilterSet error\n");
		return 0;
	}

	ret_val = sl_Stop(SL_STOP_TIMEOUT);
	if (ret_val < 0) {
		UART_PRINT("sl_Stop error\n");
		return 0;
	}

	return 1;
}

void board_init(void) {
	/* In case of TI-RTOS vector table is initialize by OS itself */
#ifndef USE_TIRTOS
	//
	// Set vector table base
	//
#if defined(ccs)
	MAP_IntVTableBaseSet((unsigned long) &g_pfnVectors[0]);
#endif
#if defined(ewarm)
	MAP_IntVTableBaseSet((unsigned long)&__vector_table);
#endif
#endif
	//
	// Enable Processor
	//
//#if defined(TARGET_IS_CC3200)
	MAP_IntMasterEnable();
//#else

//#endif

	MAP_IntEnable(FAULT_SYSTICK);

	PRCMCC3200MCUInit();
}

void setup_pin_mux() {
	//
	// Enable Peripheral Clocks
	//
	//Buttons
	MAP_PRCMPeripheralClkEnable(PRCM_GPIOA1, PRCM_RUN_MODE_CLK);
	MAP_PRCMPeripheralClkEnable(PRCM_GPIOA2, PRCM_RUN_MODE_CLK);

	// Configure PIN_64 for GPIOOutput
	MAP_PinTypeGPIO(PIN_64, PIN_MODE_0, false);
	MAP_GPIODirModeSet(GPIOA1_BASE, 0x2, GPIO_DIR_MODE_OUT);

	// Configure PIN_01 for GPIOOutput
	MAP_PinTypeGPIO(PIN_01, PIN_MODE_0, false);
	MAP_GPIODirModeSet(GPIOA1_BASE, 0x4, GPIO_DIR_MODE_OUT);

	// Configure PIN_02 for GPIOOutput
	MAP_PinTypeGPIO(PIN_02, PIN_MODE_0, false);
	MAP_GPIODirModeSet(GPIOA1_BASE, 0x8, GPIO_DIR_MODE_OUT);

	//PIN_04 for input (button)
	MAP_PinTypeGPIO(PIN_04, PIN_MODE_0, false);
	MAP_GPIODirModeSet(GPIOA1_BASE, 0x20, GPIO_DIR_MODE_IN);

	//PIN_14 for input (button)
	MAP_PinTypeGPIO(PIN_15, PIN_MODE_0, false);
	MAP_GPIODirModeSet(GPIOA2_BASE, 0x40, GPIO_DIR_MODE_IN);
}

void cc3200_init() {
	board_init();
	InitTerm();

	UART_PRINT("cc3200 starting up...\n");

	if (!configure_simplelink_to_default_state()) {
		return;
	}

	sl_Start(0, 0, 0);
	setup_pin_mux();
	GPIO_IF_LedConfigure(LED1 | LED2 | LED3);
	GPIO_IF_LedOff(MCU_ALL_LED_IND);

	SlSecParams_t sec_params = { 0 };
	sec_params.Key = WIFI_PASSWORD;
	sec_params.KeyLen = strlen(sec_params.Key);
	sec_params.Type = SL_SEC_TYPE_WPA_WPA2;
	_i8 *ssid = WIFI_SSID;
	_i16 ssid_length = strlen(WIFI_SSID);
	_i16 ret_val = sl_WlanConnect(ssid, ssid_length, 0, &sec_params, 0);
	if (ret_val != 0) {
		UART_PRINT("sl_WlanConnect error %i\n", ret_val);
		return;
	}

	while (!has_ip_address || !is_connected) {
#ifndef SL_PLATFORM_MULTI_THREADED
			_SlNonOsMainLoopTask();
#endif
	}

	UART_PRINT("cc3200 initialization complete\n");
}

void cc3200_shutdown() {
	UART_PRINT("cc3200 shutting down...\n");
	sl_Stop(SL_STOP_TIMEOUT);
	while (1);
}

#endif //MDG_CC3200
